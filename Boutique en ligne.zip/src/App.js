import React from 'react';
import Store from './components/Store';

const App = () => {
  return (
    <div className="App">
      <Store />
    </div>
  );
};

export default App;
