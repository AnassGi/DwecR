import React, { useState } from 'react';

const Catalog = ({ addToCart }) => {
  const [products, setProducts] = useState([
    { id: 1, name: "Producto 1", price: 10 },
    { id: 2, name: "Producto 2", price: 20 },
    { id: 3, name: "Producto 3", price: 30 }
  ]);

  return (
    <div>
      <h2>Tienda en línea</h2>
      <h3>Catálogo de Productos</h3>
      {products.map((product) => (
        <div key={product.id}>
          <h4>{product.name}</h4>
          <p>Precio: ${product.price}</p>
          <button onClick={() => addToCart(product)}>Agregar al Carrito</button>
        </div>
      ))}
    </div>
  );
};

export default Catalog;
